# Source preparation and historical code

`fetch.py` and `prepare.py` retain the source acquisition and preparation workflow. Prepared arrays are already included under `data/derived/`; no download is needed for the current benchmark. The active pixel-rendering and scoring implementation is in `../rendered_study/`, executed by `../reproduce_revision.py`. Other historical selection scripts are not the current scoring method.
