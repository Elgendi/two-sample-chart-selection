# Prospective reader validation — not completed research

## Aim
Test whether frozen computational pixel-recovery scores predict human estimation error for five two-group quantile differences. The benchmark itself is not a human-performance result.

## Before recruitment
Freeze the renderer, pixel observer, catalogue, task wording, target populations, practical effect size, analysis plan and code version. Obtain any institutional review and consent required for the intended recruitment. Conduct a power analysis using independently justified variance assumptions or a separately reported pilot; this document does not supply a sample-size claim or imply approval.

## Design
Use datasets withheld from algorithm development. Include independent comparisons across different distribution shapes, ranges, sample sizes and subject areas. Preserve provenance and the intended analysis unit. Render each eligible family using frozen parameter-selection rules. Do not select settings on human test responses.

Recruit readers with prespecified expertise strata. Randomize chart assignment and order, counterbalance cases, and avoid showing the same underlying comparison repeatedly to a participant where memory could affect responses. Provide consistent instructions explaining the requested lower, middle and upper quantiles. Evaluate accessibility, visual acuity needs and display conditions prospectively. Use the actual task renderings, with legible axes and labels, rather than assuming pixel-decoder calibration matches human axis reading.

## Outcomes
Primary: mean absolute error in the five estimated group differences, both in source units and divided by the prespecified pooled within-group scale. Secondary: response time, confidence, missing/invalid answers and task completion. Record group-specific estimates to detect cancellation that can conceal inaccurate recovery of both groups.

## Analysis
Prespecify the human contrast of interest and the minimum practically meaningful improvement. Model dependence from repeated participants and datasets. Assess agreement between frozen computational score differences and observed human errors on held-out cases, with uncertainty. Handle missing responses, exclusions, multiplicity and timing rules before looking at outcomes. Report genuine ties and inconclusive differences rather than forcing a unique winner. Compare the pixel score with transparent baselines and assess whether it adds predictive value.

## Claims permitted now
This is a proposed protocol only. No people were recruited, no responses collected, no ethical approval asserted, no human benefit demonstrated and no power calculation completed by the present computational revision.
